package com.virtusa.config;

public class Constants {
	public static final String ROLE_ADMIN = "admin";
	public static final String ROLE_USER = "customer";
	public static final String ROLE_DEALER = "dealer";

}
